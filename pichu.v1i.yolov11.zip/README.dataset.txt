# pichu > 2022-12-09 3:11pm
https://universe.roboflow.com/name-n524g/pichu

Provided by a Roboflow user
License: CC BY 4.0

