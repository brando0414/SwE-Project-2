# Pikachu > 2023-03-07 11:23pm
https://universe.roboflow.com/gian-b0euc/pikachu-zxwjc

Provided by a Roboflow user
License: CC BY 4.0

