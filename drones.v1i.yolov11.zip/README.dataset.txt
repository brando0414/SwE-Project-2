# drones > 2023-11-27 1:01pm
https://universe.roboflow.com/oklahoma-state-university-rcgwk/drones-hkscu

Provided by a Roboflow user
License: CC BY 4.0

